<?= $this->include('layout/header'); ?>
<?= $this->include('layout/sidebar'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layout/footer'); ?>